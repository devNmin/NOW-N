<template>
  체중그래프
</template>

<script>
export default {
  components: {
  }
}
</script>

<style scoped>
</style>
