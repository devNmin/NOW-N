<template>
  <div> <ScheduleCaseInput/><ScheduleDateInput/> <ScheduleDateInput/> </div>
</template>

<script>
import ScheduleCaseInput from '@/components/counselting/CounseltingscheduleCaseInput.vue'
import ScheduleDateInput from '@/components/counselting/CounseltingscheduleDateInput.vue'
export default {
  components: { ScheduleCaseInput, ScheduleDateInput }

}

</script>

<style>

</style>
