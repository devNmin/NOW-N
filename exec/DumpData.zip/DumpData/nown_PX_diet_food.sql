-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: i7b108.p.ssafy.io    Database: nown
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `PX_diet_food`
--

DROP TABLE IF EXISTS `PX_diet_food`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PX_diet_food` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `size` int DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `diet_id` bigint NOT NULL,
  `food_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `PX_diet_food_diet_id_50ab3d5b_fk_PX_diet_id` (`diet_id`),
  KEY `PX_diet_food_food_id_c6e3ca79_fk_PX_food_id` (`food_id`),
  CONSTRAINT `PX_diet_food_diet_id_50ab3d5b_fk_PX_diet_id` FOREIGN KEY (`diet_id`) REFERENCES `PX_diet` (`id`),
  CONSTRAINT `PX_diet_food_food_id_c6e3ca79_fk_PX_food_id` FOREIGN KEY (`food_id`) REFERENCES `PX_food` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=109 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PX_diet_food`
--

LOCK TABLES `PX_diet_food` WRITE;
/*!40000 ALTER TABLE `PX_diet_food` DISABLE KEYS */;
INSERT INTO `PX_diet_food` VALUES (1,450,'김치국',1,22),(2,250,'오곡밥',1,137),(3,250,'오곡밥',2,137),(4,150,'불고기',2,9),(5,40,'갓김치',2,6895),(6,50,'미나리나물',2,54),(7,140,'닥터유 젤리 포도맛',3,52503),(8,1197,'더블 치즈버거 오리지널(L)',4,3008),(9,190,'탄산 음료, 소다수',4,10356),(11,64,'맥너겟® 4조각',4,5601),(12,200,'고등어구이',5,6804),(13,250,'오곡밥',5,137),(18,100,'델몬트 망고 아이스크림',7,39581),(19,259,'오곡밥',8,137),(20,200,'동태찌개',8,7263),(21,210,'BLT 샌드위치',9,2577),(22,360,'순수 딸기 우유',9,1344),(23,159,'시카고 피자',10,4134),(24,190,'탄산 음료, 소다수',10,10356),(25,100,'페레로 포켓 초콜렛',11,41428),(26,900,'굴짬뽕',12,72),(27,200,'칠성사이다',12,13231),(28,250,'오곡밥',13,137),(29,250,'탕국',13,39),(30,40,'배추김치',13,6902),(31,230,'치킨 로제 파스타',14,5150),(32,190,'탄산 음료, 소다수',14,10356),(33,100,'소주, 알코올 17.8%',15,10378),(34,250,'오곡밥',15,137),(35,250,'갈치찌개',15,7252),(36,100,'맥주, 알코올 4.5%',15,10372),(38,190,'탄산 음료, 소다수',16,10356),(39,600,'아이스아메리카노L',17,1259),(40,100,'소주, 알코올 17.8%',18,10378),(41,100,'맥주, 알코올 4.5%',18,10372),(42,100,'매콤제육볶음 ',18,7596),(43,900,'굴짬뽕',19,72),(44,190,'탄산 음료, 소다수',19,10356),(48,200,'찐고구마',21,6796),(49,150,'닭가슴살샐러드',21,7128),(50,250,'오곡밥',22,137),(51,150,'불고기',22,9),(52,190,'탄산 음료, 소다수',22,10356),(53,200,'찐고구마',23,6796),(54,150,'닭가슴살샐러드',23,7128),(55,200,'찐고구마',24,6796),(56,150,'닭가슴살샐러드',24,7128),(57,450,'비비고 김치낙지죽',25,28642),(58,330,'본죽 전복죽(330g)',26,38074),(59,200,'찐고구마',27,6796),(60,150,'닭가슴살샐러드',27,7128),(61,25,'데일리단백질쉐이크 초코',28,23192),(62,150,'닭가슴살샐러드',29,7128),(63,100,'사과, 홍옥, 생것',29,9051),(64,25,'데일리단백질쉐이크 초코',30,23192),(65,150,'닭가슴살샐러드',31,7128),(66,200,'찐고구마',31,6796),(67,100,'사과, 홍옥, 생것',32,9051),(68,250,'오곡밥',33,137),(69,250,'제육볶음',33,7074),(70,100,'소주, 알코올 17.8%',34,10378),(71,100,'맥주, 알코올 4.5%',34,10372),(72,250,'갈치찌개',34,7252),(73,190,'탄산 음료, 소다수',34,10356),(74,100,'사과, 홍옥, 생것',35,9051),(75,25,'데일리단백질쉐이크 초코',36,23192),(76,200,'찐고구마',36,6796),(77,600,'아이스아메리카노L',37,1259),(79,150,'닭가슴살샐러드',39,7128),(80,25,'데일리단백질쉐이크 초코',40,23192),(81,200,'찐고구마',40,6796),(83,25,'데일리단백질쉐이크 초코',41,23192),(84,150,'닭가슴살샐러드',42,7128),(85,200,'찐고구마',43,6796),(87,100,'맛있닭 닭가슴살 소시지 훈제맛',44,26031),(88,197,'더블 치즈버거 오리지널(L)',45,3008),(89,143,'맵피자 L',45,832),(90,100,'페레로 포켓 초콜렛',46,41428),(91,250,'오곡밥',47,137),(92,250,'제육볶음',47,7074),(93,40,'배추김치',47,6902),(94,200,'칠성사이다',47,13231),(95,100,'소주, 알코올 17.8%',48,10378),(96,100,'맥주, 알코올 4.5%',48,10372),(97,300,'돼지묵은지짜글이',48,34954),(98,25,'데일리단백질쉐이크 초코',49,23192),(99,100,'맛있닭 닭가슴살 소시지 훈제맛',50,26031),(101,250,'닭가슴살샐러드',52,7128),(103,250,'산딸기',54,2014),(107,NULL,'닭갈비',57,2),(108,NULL,'문어밤 슈림프(오리지널 M)',57,314);
/*!40000 ALTER TABLE `PX_diet_food` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19 11:01:46
