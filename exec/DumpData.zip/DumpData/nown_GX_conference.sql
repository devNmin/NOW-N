-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: i7b108.p.ssafy.io    Database: nown
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `GX_conference`
--

DROP TABLE IF EXISTS `GX_conference`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `GX_conference` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `owner_id` int NOT NULL,
  `password` int DEFAULT NULL,
  `category` int NOT NULL,
  `start_time` datetime(6) NOT NULL,
  `end_time` datetime(6) DEFAULT NULL,
  `title` varchar(100) NOT NULL,
  `description` longtext NOT NULL,
  `max_user` int NOT NULL,
  `thumnail` longtext NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GX_conference`
--

LOCK TABLES `GX_conference` WRITE;
/*!40000 ALTER TABLE `GX_conference` DISABLE KEYS */;
INSERT INTO `GX_conference` VALUES (1,22,NULL,5,'2022-08-19 01:50:38.138657','2022-08-19 02:48:58.607000','1시간 동안 런닝 뛰실분!','3분 걷기-7분 뛰기를 반복합니다! 안하시는분 체크합니다~',6,'https://firebasestorage.googleapis.com/v0/b/commonproject-nown.appspot.com/o/rooms%2F22_1%EC%8B%9C%EA%B0%84%20%EB%8F%99%EC%95%88%20%EB%9F%B0%EB%8B%9D%20%EB%9B%B0%EC%8B%A4%EB%B6%84!?alt=media&token=1479a775-01bd-4a79-b787-1638a144f3c6',0),(2,24,NULL,0,'2022-08-19 01:53:44.064041','2022-08-19 02:52:42.977000','필라테스 재능기부합니다~','현재 필라테스 강사를 하고 있습니다. 배워보고 싶으신분 들어오세요!',6,'https://firebasestorage.googleapis.com/v0/b/commonproject-nown.appspot.com/o/rooms%2F24_%ED%95%84%EB%9D%BC%ED%85%8C%EC%8A%A4%20%EC%9E%AC%EB%8A%A5%EA%B8%B0%EB%B6%80%ED%95%A9%EB%8B%88%EB%8B%A4~?alt=media&token=5d74f9b9-b425-4920-a0fe-94d0fa412eb8',0),(3,24,NULL,3,'2022-08-19 01:56:00.234180','2022-08-19 03:54:06.198000','60분 전신 스트레칭','요즘 몸이 많이 쑤시네요...ㅠ 스트레칭 좀 가르쳐 주실분~~',4,'https://firebasestorage.googleapis.com/v0/b/commonproject-nown.appspot.com/o/rooms%2F24_60%EB%B6%84%20%EC%A0%84%EC%8B%A0%20%EC%8A%A4%ED%8A%B8%EB%A0%88%EC%B9%AD?alt=media&token=107f2ed8-4dd5-4cb5-8ae1-5a72c05e6969',0);
/*!40000 ALTER TABLE `GX_conference` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19 11:01:47
