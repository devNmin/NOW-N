-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: i7b108.p.ssafy.io    Database: nown
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_permission` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=93 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` VALUES (1,'Can add user',1,'add_user'),(2,'Can change user',1,'change_user'),(3,'Can delete user',1,'delete_user'),(4,'Can view user',1,'view_user'),(5,'Can add tag',2,'add_tag'),(6,'Can change tag',2,'change_tag'),(7,'Can delete tag',2,'delete_tag'),(8,'Can view tag',2,'view_tag'),(9,'Can add exercise_ category',3,'add_exercise_category'),(10,'Can change exercise_ category',3,'change_exercise_category'),(11,'Can delete exercise_ category',3,'delete_exercise_category'),(12,'Can view exercise_ category',3,'view_exercise_category'),(13,'Can add conference',4,'add_conference'),(14,'Can change conference',4,'change_conference'),(15,'Can delete conference',4,'delete_conference'),(16,'Can view conference',4,'view_conference'),(17,'Can add user_ conference',5,'add_user_conference'),(18,'Can change user_ conference',5,'change_user_conference'),(19,'Can delete user_ conference',5,'delete_user_conference'),(20,'Can view user_ conference',5,'view_user_conference'),(21,'Can add weight',6,'add_weight'),(22,'Can change weight',6,'change_weight'),(23,'Can delete weight',6,'delete_weight'),(24,'Can view weight',6,'view_weight'),(25,'Can add request_ counsel',7,'add_request_counsel'),(26,'Can change request_ counsel',7,'change_request_counsel'),(27,'Can delete request_ counsel',7,'delete_request_counsel'),(28,'Can view request_ counsel',7,'view_request_counsel'),(29,'Can add member_ coach',8,'add_member_coach'),(30,'Can change member_ coach',8,'change_member_coach'),(31,'Can delete member_ coach',8,'delete_member_coach'),(32,'Can view member_ coach',8,'view_member_coach'),(33,'Can add counsel',9,'add_counsel'),(34,'Can change counsel',9,'change_counsel'),(35,'Can delete counsel',9,'delete_counsel'),(36,'Can view counsel',9,'view_counsel'),(37,'Can add diet',10,'add_diet'),(38,'Can change diet',10,'change_diet'),(39,'Can delete diet',10,'delete_diet'),(40,'Can view diet',10,'view_diet'),(41,'Can add diet_ food',11,'add_diet_food'),(42,'Can change diet_ food',11,'change_diet_food'),(43,'Can delete diet_ food',11,'delete_diet_food'),(44,'Can view diet_ food',11,'view_diet_food'),(45,'Can add food',12,'add_food'),(46,'Can change food',12,'change_food'),(47,'Can delete food',12,'delete_food'),(48,'Can view food',12,'view_food'),(49,'Can add schedule',13,'add_schedule'),(50,'Can change schedule',13,'change_schedule'),(51,'Can delete schedule',13,'delete_schedule'),(52,'Can view schedule',13,'view_schedule'),(53,'Can add training_ history',14,'add_training_history'),(54,'Can change training_ history',14,'change_training_history'),(55,'Can delete training_ history',14,'delete_training_history'),(56,'Can view training_ history',14,'view_training_history'),(57,'Can add article',15,'add_article'),(58,'Can change article',15,'change_article'),(59,'Can delete article',15,'delete_article'),(60,'Can view article',15,'view_article'),(61,'Can add comment',16,'add_comment'),(62,'Can change comment',16,'change_comment'),(63,'Can delete comment',16,'delete_comment'),(64,'Can view comment',16,'view_comment'),(65,'Can add blacklisted token',17,'add_blacklistedtoken'),(66,'Can change blacklisted token',17,'change_blacklistedtoken'),(67,'Can delete blacklisted token',17,'delete_blacklistedtoken'),(68,'Can view blacklisted token',17,'view_blacklistedtoken'),(69,'Can add outstanding token',18,'add_outstandingtoken'),(70,'Can change outstanding token',18,'change_outstandingtoken'),(71,'Can delete outstanding token',18,'delete_outstandingtoken'),(72,'Can view outstanding token',18,'view_outstandingtoken'),(73,'Can add log entry',19,'add_logentry'),(74,'Can change log entry',19,'change_logentry'),(75,'Can delete log entry',19,'delete_logentry'),(76,'Can view log entry',19,'view_logentry'),(77,'Can add permission',20,'add_permission'),(78,'Can change permission',20,'change_permission'),(79,'Can delete permission',20,'delete_permission'),(80,'Can view permission',20,'view_permission'),(81,'Can add group',21,'add_group'),(82,'Can change group',21,'change_group'),(83,'Can delete group',21,'delete_group'),(84,'Can view group',21,'view_group'),(85,'Can add content type',22,'add_contenttype'),(86,'Can change content type',22,'change_contenttype'),(87,'Can delete content type',22,'delete_contenttype'),(88,'Can view content type',22,'view_contenttype'),(89,'Can add session',23,'add_session'),(90,'Can change session',23,'change_session'),(91,'Can delete session',23,'delete_session'),(92,'Can view session',23,'view_session');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19 11:01:46
