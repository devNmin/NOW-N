-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: i7b108.p.ssafy.io    Database: nown
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `accounts_user`
--

DROP TABLE IF EXISTS `accounts_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `accounts_user` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `user_id` varchar(15) NOT NULL,
  `nickname` varchar(100) DEFAULT NULL,
  `email` varchar(254) NOT NULL,
  `name` varchar(30) NOT NULL,
  `birth` int NOT NULL,
  `phone_number` int NOT NULL,
  `grade` varchar(10) NOT NULL,
  `img` longtext,
  `age` int DEFAULT NULL,
  `gender` int DEFAULT NULL,
  `height` double DEFAULT NULL,
  `user_weight` double DEFAULT NULL,
  `object_weight` double DEFAULT NULL,
  `exercise_category` int DEFAULT NULL,
  `career` varchar(500) DEFAULT NULL,
  `diet_price` int DEFAULT NULL,
  `exercise_price` int DEFAULT NULL,
  `comment` varchar(500) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `alarm` tinyint(1) NOT NULL,
  `hashtag_cnt` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounts_user`
--

LOCK TABLES `accounts_user` WRITE;
/*!40000 ALTER TABLE `accounts_user` DISABLE KEYS */;
INSERT INTO `accounts_user` VALUES (1,'pbkdf2_sha256$260000$MurEep0IW9vahwckzoZ9zn$Xg+24Vtm7fmV67NU1qoLVFNROmfYqDbqc+YlQul0z8E=',NULL,0,'test','나는강호동이다','dfsdff@naver.com','싸피짱이야',19880101,1015154646,'일반유저','https://firebasestorage.googleapis.com/v0/b/commonproject-nown.appspot.com/o/profiles%2Fundefined?alt=media&token=1043d674-cc03-4468-92fa-9adc403d3648',NULL,NULL,185,87,85,NULL,NULL,NULL,NULL,NULL,1,0,0,0),(2,'pbkdf2_sha256$260000$rT9Ww1gfa1rxOnCGOc0bKx$u6JQrKKRoV7dvNKG3t8fUvh6oIs9Xl4lBNekhVZg6eY=',NULL,0,'test2',NULL,'fvxcv@naver.com','나는운동짱',17460401,1015245747,'트레이너','https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTJ6yI5v-1UCyMx8CdTpABg9QzItPHcPLZh7_1ZnzOpTg&s',32,1,NULL,NULL,NULL,4,'13',40000,20000,'모든살을 빼드립니다',1,0,1,0),(3,'1234','1000-01-01 00:00:02.000000',0,'SSAFY3','','SSAFY3@naver.com','박싸피',19960910,1001233310,'일반유저','',0,0,0,0,0,0,'',0,0,'',0,0,0,0),(4,'1234','1000-01-01 00:00:03.000000',0,'SSAFY4','','SSAFY4@naver.com','최싸피',19960911,1045677126,'일반유저','',0,0,0,0,0,0,'',0,0,'',0,0,0,0),(5,'1234','1000-01-01 00:00:04.000000',0,'SSAFY5','','SSAFY5@naver.com','김싸피',19960912,1090120942,'일반유저','',0,0,0,0,0,0,'',0,0,'',0,0,0,0),(6,'1234','1000-01-01 00:00:05.000000',0,'SSAFY6','','SSAFY6@naver.com','이싸피',19960913,1034564758,'일반유저','',0,0,0,0,0,0,'',0,0,'',0,0,0,0),(7,'1234','1000-01-01 00:00:06.000000',0,'SSAFY7','','SSAFY7@naver.com','박싸피',19960914,1079008574,'일반유저','',0,0,0,0,0,0,'',0,0,'',0,0,0,0),(8,'1234','1000-01-01 00:00:07.000000',0,'SSAFY8','','SSAFY8@naver.com','최싸피',19960915,1023452390,'일반유저','',0,0,0,0,0,0,'',0,0,'',0,0,0,0),(9,'1234','1000-01-01 00:00:08.000000',0,'SSAFY9','','SSAFY9@naver.com','김싸피',19960916,1067896206,'일반유저','',0,0,0,0,0,0,'',0,0,'',0,0,0,0),(10,'1234','1000-01-01 00:00:09.000000',0,'SSAFY10','','SSAFY10@naver.com','이싸피',19960917,1012340022,'일반유저','',0,0,0,0,0,0,'',0,0,'',0,0,0,0),(11,'1234','1000-01-01 00:00:10.000000',0,'SSAFY11','','SSAFY11@naver.com','박트레이너',19960918,1056783838,'트레이너','https://firebasestorage.googleapis.com/v0/b/commonproject-nown.appspot.com/o/trainer%2F%EA%B0%95%ED%98%B8%EB%8F%99.jpg?alt=media&token=7e7f51ed-f208-4ade-af21-e8eb5ac0e05f',0,0,0,0,0,1,'',30000,25000,'',0,0,1,0),(12,'1234','1000-01-01 00:00:11.000000',0,'SSAFY12','','SSAFY12@naver.com','최트레이너',19960919,1001227654,'트레이너','',0,0,0,0,0,2,'',30000,35000,'',0,0,0,0),(13,'1234','1000-01-01 00:00:12.000000',0,'SSAFY13','','SSAFY13@naver.com','김트레이너',19960920,1045671470,'트레이너','',0,0,0,0,0,4,'',35000,40000,'',0,0,0,0),(14,'1234','1000-01-01 00:00:13.000000',0,'SSAFY14','','SSAFY14@naver.com','이트레이너',19960921,1090115286,'트레이너','',0,0,0,0,0,0,'',0,0,'',0,0,0,0),(15,'1234','1000-01-01 00:00:14.000000',0,'SSAFY15','','SSAFY15@naver.com','박트레이너',19960922,1034559102,'트레이너','',0,0,0,0,0,0,'',0,0,'',0,0,0,0),(16,'1234','1000-01-01 00:00:15.000000',0,'SSAFY16','','SSAFY16@naver.com','최트레이너',19960923,1079002918,'트레이너','https://firebasestorage.googleapis.com/v0/b/commonproject-nown.appspot.com/o/trainer%2F%EB%A9%94%EC%8B%9C.jpg?alt=media&token=fb0a11a4-090d-430c-b67e-a8a644f99911',0,0,0,0,0,0,'',0,0,'',0,0,0,0),(17,'1234','1000-01-01 00:00:16.000000',0,'SSAFY17','','SSAFY17@naver.com','김트레이너',19960924,1023446734,'트레이너','https://firebasestorage.googleapis.com/v0/b/commonproject-nown.appspot.com/o/trainer%2F%EA%B9%80%EC%A2%85%EA%B5%AD.jpg?alt=media&token=dd06e2e1-f053-4f62-a2ef-f1ab54c9f948',0,0,0,0,0,0,'',0,0,'',0,0,0,0),(18,'1234','1000-01-01 00:00:17.000000',0,'SSAFY18','','SSAFY18@naver.com','이트레이너',19960925,1067890550,'트레이너','https://firebasestorage.googleapis.com/v0/b/commonproject-nown.appspot.com/o/trainer%2F%EA%B9%80%EC%97%B0%EA%B2%BD.jpg?alt=media&token=f29c3ad5-10b6-4b16-98cf-48aa766feb4c',0,0,0,0,0,0,'',0,0,'',0,0,0,0),(19,'1234','1000-01-01 00:00:18.000000',0,'SSAFY19','','SSAFY19@naver.com','박트레이너',19960926,1012334366,'트레이너','https://firebasestorage.googleapis.com/v0/b/commonproject-nown.appspot.com/o/trainer%2F%EA%B9%80%EA%B3%84%EB%9E%80.png?alt=media&token=53c9a88e-fe86-4cf6-be00-8769048b2944',0,0,0,0,0,0,'',0,0,'',0,0,0,0),(20,'1234','1000-01-01 00:00:19.000000',0,'SSAFY20','','SSAFY20@naver.com','최트레이너',19960927,1056778182,'트레이너','https://firebasestorage.googleapis.com/v0/b/commonproject-nown.appspot.com/o/trainer%2F%EA%B0%95%ED%98%B8%EB%8F%99.jpg?alt=media&token=7e7f51ed-f208-4ade-af21-e8eb5ac0e05f',0,0,0,0,0,0,'',0,0,'',0,0,0,0),(21,'pbkdf2_sha256$260000$FmHecbZ18RnbO7R0OAscGG$Y+O87Qy77G6EdhzUMIWIkkF6woKeu93YDKW7y/+sWWE=',NULL,0,'ttest',NULL,'afdg@naver.com','트레이너임',16240101,1034343453,'트레이너',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,0),(22,'pbkdf2_sha256$260000$x3wVOiJtgY3bP73r9XBWtP$hMRQNbZFIPywOOC9HRZN12+6O/t+u7jq9IYzM4sf7SY=',NULL,0,'gkrwns1',NULL,'1234@naver.com','김학준',12340420,1012341234,'일반유저',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,0),(23,'pbkdf2_sha256$260000$TYfyfBwBRCPRpWaDRoCkIk$D3DoWBuYennMhz+gw8TpseZt7aM6vloJG9zzQVW2cuA=',NULL,0,'imssafy','나는싸피짱','imssafy@naver.com','나는싸피인',19950819,1012344321,'일반유저','https://firebasestorage.googleapis.com/v0/b/commonproject-nown.appspot.com/o/profiles%2Fundefined?alt=media&token=d028996e-7b40-4751-96d8-23b8499a43b9',NULL,NULL,177,76,85,NULL,NULL,NULL,NULL,NULL,1,0,0,0),(24,'pbkdf2_sha256$260000$oiRFiCHpvbymomauD2Qe23$OiOUz+iF4eQlE4LRcvEVx5+Y7/VLZZyPOXlsjGPBmME=',NULL,0,'wpgml',NULL,'wpgml@naver.com','이제희',12341118,1012341234,'일반유저',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,0);
/*!40000 ALTER TABLE `accounts_user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19 11:01:50
